// =============================================================
//  SOC REPORT DATA — update this file each reporting period
//  No server needed. Just edit values and open soc-report.html
// =============================================================

const REPORT = {

  meta: {
    title:       "SOC REPORT: TOP MANAGEMENT",
    subtitle:    "Executive Overview",
    period:      "October 2023",
    generatedBy: "SOC Manager / CISO",
    date:        "2023-10-31",
    company:     "Corporate Security"
  },

  kpis: {
    totalIncidents:  { value: "2,841",       trend: "up",  label: "Total Incidents Triggered"   },
    highCritical:    { value: "42",           trend: "up",  label: "High / Critical Incidents"   },
    avgDetectTime:   { value: "2 hrs 15 min", trend: null,  label: "Avg. Time to Detect (MTTD)"  },
    avgResponseTime: { value: "4 hrs 50 min", trend: null,  label: "Avg. Time to Respond (MTTR)" }
  },

  incidentSeverity: {
    critical: 21,
    high:     35,
    medium:   28,
    low:      16
  },

  incidentTrends: [
    { month: "Jan", total: 120, critical:  8 },
    { month: "Feb", total: 140, critical: 10 },
    { month: "Mar", total: 110, critical:  7 },
    { month: "Apr", total: 160, critical: 12 },
    { month: "May", total: 130, critical:  9 },
    { month: "Jun", total: 150, critical: 11 },
    { month: "Jul", total: 170, critical: 14 },
    { month: "Aug", total: 190, critical: 18 },
    { month: "Sep", total: 175, critical: 15 },
    { month: "Oct", total: 200, critical: 22 },
    { month: "Nov", total: 185, critical: 19 },
    { month: "Dec", total: 210, critical: 25 }
  ],

  incidentStatus: {
    open:         32,
    inProgress:   28,
    closed:       30,
    awaitingInfo: 10
  },

  topAttackSources: ["US", "Brazil", "Germany", "Russia", "China"],

  topIncidentCategories: [
    { name: "Attack Blocked on Outermost Layer",             count:  80 },
    { name: "Phishing / Spam Email Blocked",                 count: 260 },
    { name: "Malware Captured on Honeypot / Antivirus",      count: 180 },
    { name: "IP Captured on Honeypot",                       count: 180 },
    { name: "Total Alerts (UseCase) Triggered on SIEM",      count: 100 },
    { name: "Attack Blocked on Outermost Layer (2nd Layer)", count:  80 },
    { name: "DDoS Attack Blocked on AntiDDoS / WAF",         count: 270 },
    { name: "Threat Intel Advisory Received",                count: 150 },
    { name: "Ransomware Attempt Detected",                   count:  90 },
    { name: "DDoS Attack Recorded",                          count:  60 }
  ],

  proactiveDefenses: {
    totalIPsBlocked: "142,500+",
    topBlockedIPs: [
      { ip: "192.168.1.13", flag: "🇺🇸", count: 13 },
      { ip: "192.168.1.17", flag: "🇺🇸", count:  6 },
      { ip: "192.168.3.23", flag: "🇩🇪", count:  4 },
      { ip: "192.168.1.23", flag: "🇬🇧", count:  1 },
      { ip: "142.168.1.93", flag: "🇮🇹", count:  1 }
    ],
    threatHunting: {
      hunts:         23,
      findings:      14,
      improvements:   2
    }
  },

  strategicInsights: {
    currentRiskPosture: "Elevated risk posture identified; pre-emptive controls and high-security gap mitigation in progress.",
    keySecurityGaps:    "Critical security gaps require urgent remediation. Controls are being reviewed and improvement plans activated.",
    urgentRecommendations: [
      "Explore new security policies and enforce compliance in all business units.",
      "Engage Security Manager / CSO with updated anomaly and threat reporting.",
      "Involve EVR intelligence across all security recommendations and handling protocols.",
      "Consider security tools upgrade and deployment of threat-response automated centers."
    ]
  }

};
